package eCapitalAutomation;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;




public class Test {
	public static void main(String[] args) {
		
		
		System.setProperty("webdriver.gecko.driver",".\\Driver\\geckodriver.exe");
		WebDriver driver = new FirefoxDriver();
		
		
		driver.get("https://www.just-eat.co.uk/");
	    driver.manage().window().maximize();
	    driver.findElement(By.xpath("//button[contains(.,\'Accept all cookies\')]")).click();
	    driver.findElement(By.name("postcode")).sendKeys("AR51 1AA"+Keys.RETURN);
	    
	    driver.findElement(By.xpath("//html//body//main//div[4]//div[2]//main//div//div[2]//div//div[4]//span")).click();
	    
	    driver.close();
	    driver.quit();
	}
}
