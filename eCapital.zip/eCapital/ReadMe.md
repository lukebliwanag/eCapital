Change Compiler Version to 1.7
	Project > Properties > Java Compiler > Uncheck Use compliance.... and select 1.7 from dropdown.
	
Ensure that the latest Selenium Java Jar Files are added under Java Build Path > Libraries
	Please download from: https://www.selenium.dev/downloads/
	
Code is created for FireFox, Please ensure Driver (geckodriver.exe) is on the project "Driver" folder (.\Driver)